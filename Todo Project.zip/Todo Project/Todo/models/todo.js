const mongoose = require('mongoose');
const Joi = require('joi');

const todoSchema = new mongoose.Schema({
    title: {
        type: String,
        minlength: 5,
        maxlength: 50,
        required: true
    },
    shortDescription: {
        type: String,
        minlength: 20,
        maxlength: 200,
        required: true
    },
    longDescription: {
        type: String,
        minlength: 50,
        maxlength: 1000,
        required: true
    },
    author: {
        type: String,
        minlength: 5,
        maxlength: 50,
        required: true
    }
   
});

const Todo = mongoose.model('Todo', todoSchema);

const validateTodo = (todo) => {
    const schema = {
        title: Joi.string().min(5).max(50).required(),
        shortDescription: Joi.string().min(20).max(200).required(),
        longDescription: Joi.string().min(50).max(1000).required(),
        author: Joi.string().min(5).max(50).required(),
      
    }

    return Joi.validate(todo, schema);
}

exports.Todo = Todo;
exports.validate = validateTodo;