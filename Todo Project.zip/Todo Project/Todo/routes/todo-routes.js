const express = require('express');
const auth = require('../middleware/auth');
const {addTodo, getTodos, getOneTodo, updateTodo, deleteTodo} = require('../controllers/todoController');

const router = express.Router();

router.post('/todo', auth, addTodo);
router.get('/todos', auth,  getTodos);
router.get('/todo/:id',auth, getOneTodo);
router.put('/todo/:id', auth, updateTodo);
router.delete('/todo/:id', auth, deleteTodo);


module.exports = {
    routes: router
}