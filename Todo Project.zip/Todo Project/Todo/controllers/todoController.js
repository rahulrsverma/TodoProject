const { model } = require('mongoose');
const {Todo, validate} = require('../models/todo');


const addTodo = async (req, res, next) => {
        const {error} =  validate(req.body);
        if(error) return res.status(422).send(error.details[0].message);

        let todo = new Todo({
            title: req.body.title,
            shortDescription: req.body.shortDescription,
            longDescription: req.body.longDescription,
            author: req.body.author
           
        });

        todo =  await todo.save(); 
        res.send(todo);
}

const getTodos = async (req, res, next) => {
    const todos = await Todo.find().sort('title').exec();
    res.send(todos);
}

const getOneTodo = async (req, res, next) => {
    const todo = await Todo.findById(req.params.id);
    if(!todo) return res.status(401).send('The Todo with the given id not found');

    res.send(todo);
}

const updateTodo = async (req, res, next) => {
    const {error} = validate(req.body);
    if(error) return res.status(422).send(error.details[0].message);

    let todo = await Todo.findByIdAndUpdate(req.params.id, {
        title: req.body.title,
        shortDescription: req.body.shortDescription,
        longDescription: req.body.longDescription,
        author: req.body.author
    }, {new: true});

    if(!todo) return res.status(401).send('The Todo with the given id not found');
    res.send(todo);
}

const deleteTodo = async (req, res, next) => {
    const todo = await Todo.findByIdAndRemove(req.params.id);
    if(!todo) return res.status(401).send('The Todo with the given id not found');

    res.send(todo);
}


module.exports = {
    addTodo,
    getTodos,
    getOneTodo,
    updateTodo,
    deleteTodo
}